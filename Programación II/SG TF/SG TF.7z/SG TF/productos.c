#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct info{
	int codigo;
	char nombre[104];
}est;
int main(){
	FILE *fp = NULL;
	est producto;
	int i = 0;
	fp = fopen("productos", "rb");
	
	for(i; i < 18; i = i + 1){
		fread(&producto.codigo, 4, 1, fp);
		fread(&producto.nombre, 50, 1, fp);
		printf("%i %s", producto.codigo, producto.nombre);
		printf("\n");
	}
	return 0;
}
