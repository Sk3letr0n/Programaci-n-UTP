#include <stdio.h>
#include <stdlib.h>

typedef struct info{
	int codigo;
	char nombre[52];
}est;

int main(){
	FILE *fp = fopen("ventas", "r");	
	int i = 0;
	int dato = 0;
	while(i <= 96){
		dato = fgetc(fp);
		printf("%c ", dato);
		if(dato == 64){
			printf("\n");
		}
		i = i + 1;
	}
	return 0;
}
