#include <stdio.h>
#include <stdlib.h>
#define CP_UTF8 65001

int main(){

    system("cls");

    unsigned char valor = 0;
    long int i = 0;
    char band = 'F';

    FILE *fp1 = NULL, *fp2 = NULL;

    fp1 = fopen("confidencial06", "rb");
    fp2 = fopen("Desencriptado06","wb");


    while(i <= 2980){

        valor = fgetc(fp1) - 69;
        printf(" %c / %i -> ", valor, valor);

        if(valor == 143){
            valor = 67;
        }
        if(valor == 216){
            valor = 32;
        }
        if(valor == 119){
            valor = 79;
        }
        if(valor == 243){
            valor = 10;
        }
        if(valor == 199){
            valor = 49;
        }
        if(valor == 214){
            valor = 44;
        }
        if(valor == 193){
            valor = 40;
        }
        if(valor == 194){
            valor = 41;
        }
        if(valor == 44){
            valor = 76;
        }
        if(valor == 34){
            valor = 67;
  		}
		if(valor == 183){
            valor = 32;
        }
        if(valor == 175){
            valor = 77;
		}
		if(valor == 192){
			valor = 32;
		}
        if(valor == 78){
            valor == 65;
        }
        if(valor == 192){ //'�'
            fputc(-62, fp2);
            fputc(-65, fp2);
            band = 'V';
        }
        if(valor == 208){ //'-'
            /*fputc(-30, fp2);
            fputc(-108, fp2);
            fputc(-128, fp2);
            band = 'V';*/
            valor = 65;
        }
        if(valor == 215){
            valor = 50;
        }
        if(valor == 26){
            band = 'V';
        }
        if(valor == 198){
            valor = 48;
        }
        if(valor == 207){
            valor = 53;
        }
        if(valor == 187){
            valor = 77;
        }
        
        if(valor == 196){
            valor = 82;
        }
        if(valor == 110){
            valor = 144;
        }
        if(valor == 213){
            valor = 71;
        }
        if(valor == 12){
            band = 'V';
        }

        if(valor == 135){ //�
            fputc(-61, fp2);
            fputc(-95, fp2);
            band = 'V';
        }
        if(valor == 142){ //�
            fputc(-61, fp2);
            fputc(-87, fp2);
            band = 'V';
        }
        if(valor == 146){ //�
            fputc(-61, fp2);
            fputc(-83, fp2);
            band = 'V';
        }
        if(valor == 151){ //�
            fputc(-61, fp2);
            fputc(-77, fp2);
            band = 'V';
        }
        if(valor == 156){ //�
            fputc(-61, fp2);
            fputc(-70, fp2);
            band = 'V';
        }
        if(valor == 150){ //�
            fputc(-61, fp2);
            fputc(-79, fp2);
            band = 'V';
        }
        if(band == 'F'){
           fputc(valor, fp2);
        }

        i = i + 1;
        band = 'F';
 		printf(" %c / %i \n", valor, valor);
    }
    fclose(fp1);
    fclose(fp2);
    
    return 0;
}
