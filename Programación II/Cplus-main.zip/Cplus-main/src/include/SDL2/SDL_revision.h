#define SDL_REVISION "https://github.com/libsdl-org/SDL.git@55b03c7493a7abed33cf803d1380a40fa8af903f"
#define SDL_REVISION_NUMBER 0
