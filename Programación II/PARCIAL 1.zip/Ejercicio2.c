/*
Fecha: 01/05/2022
Hora: 7:00 pm.
Version: 1.2
Autor: CRISTIAN DAVID ARANGO TORRES
lenguaje: C(ISO/IEC).
Version lenguaje: 11
Presentado a: Doctor Ricardo Moreno Laverde.
Organizacion: Universidad tecnologica de pereira.
Programa: Ingenieria de sistemas y computacion.
Asignatura: IS284 Programacion 2.
Descripcion: esta funcion llena el array con 0 o 1 y deja los borden en 0.
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>


void rellenar_array(char qr[]);
void imprimir_array(char qr[]);
int comprobar(char qr[]);
void imprimir(char qr[]);

int main()
{
	srand(time(NULL));
	char qr [900];
	rellenar_array(qr);
	imprimir_array(qr);
	imprimir(qr);
	printf("Requisitos:\na) Los pixeles de la periferia estan siempre en blanco.\nb) El codigotiene reservados un cuadrado 7x7 pixeles encajado en la parte mas externa superior derecha, que\ndebe estar formado por al menos 25 pixeles negros, con cualquier disposicion.\n");
	printf("c) En la septima fila, las columnas 2, 4 y 25 del arreglo son pixeles de color negro.\nCualquier producto que no cumpla los tres requisitos anteriores se consideran falsificado. El numero de errores se\ncalculara teniendo en cuenta solo el ultimo requisito (c),");
	printf("asignado un punto por cada pixel de los citados que no\nsea negro.\n");
	comprobar(qr);
}

void imprimir(char qr[])
{
	int alto = 0;
	printf("                         1                   2         \n");
	printf("     0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9\n");
	printf("    %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
	218,196,194,196,194,196,194,196,194,196,194,
	196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,
	196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,194,196,191);
	
	for(alto; alto <= 29; alto++)
    {
		if(alto < 10)
        {
			printf("%i   ", alto);
		}
        else
        {
			printf("%i  ", alto);
		}
		int ancho=0;
		while(ancho <= 29)
        { 
			if(qr[(alto * 30) + ancho] == 1)
				printf("%c%c",179,219);
				
			else
				printf("%c ", 179);

			 ancho=ancho+1;
		}
		printf("%c %i\n",179,alto);
		if (alto<29)
		printf("    %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
	195,196,197,196,197,196,197,196,197,196,197,
	196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,
	196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,197,196,180);
	}
	printf("    %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
	192,196,193,196,193,196,193,196,193,196,193,
	196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,
	196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,193,196,217);
	printf("     0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9\n");
	
	return;
}

void rellenar_array(char qr[])
{
	int ancho = 0;
	int alto = 0;
	for(ancho; ancho <= 29; ancho++)
    {
		for(alto = 0; alto <= 29; alto++)
        {
			if(ancho == 0 || ancho == 29 || alto == 0 || alto == 29)
            {
				qr[(ancho * 30) + alto] = 0; //bordes blancos
			}
            else
            {
				if(rand()%3 == 0) //33.3% probabilidad
                {
					qr[(ancho * 30) + alto] = 1;
				}
                else
                {
					qr[(ancho * 30) + alto] = 0;
				}
			}
		}
	}
	return;
}

/*
Descripcion: esta funcion imprime el array.
*/
void imprimir_array(char qr[])
{
	int alto = 0;
	int ancho = 0;
	printf("               1         2         \n");
	printf("     012345678901234567890123456789\n");
	printf("    +------------------------------+\n");
	for(alto; alto <= 29; alto++)
    {
		if(alto < 10)
        {
			printf("%i   |", alto);
		}
        else
        {
			printf("%i  |", alto);
		}
	for(ancho = 0; ancho <= 29; ancho++)
    {
		if(qr[(alto * 30) + ancho] == 1)
			printf("%c", 219);
		else
			printf("%c", 32);
	}
		printf("|  %i\n", alto);
	}
	printf("    +------------------------------+\n");
	printf("     012345678901234567890123456789\n\n");

	return;
}

/*
Descripcion: esta funcion comprueba las condiciones del ejercisio.
*/
int comprobar(char qr[])
{
	int v1 = 1, v2 = 1, ancho = 0, alto = 0, negros = 0, errores = 0;
	for(ancho; ancho <= 29; ancho++)
    {
		if(qr[ancho * 30] == 1 || qr[(ancho * 30) + 29] == 1)
			v1 = 0;
	}
	for(alto; alto <= 29; alto++)
    {
		if(qr[alto] == 1 || qr[(29 * 30) + alto] == 1)
			v2 = 0;
	}
	for(ancho = 22; ancho <= 28; ancho++)
    {
		for(alto = 1; alto <= 7; alto++)
        {
			if(qr[(alto * 30) + ancho] == 1)
				negros++;
		}
	}
	if(v1 && v2)
		printf("Condicion a: Se cumple.\n");
	else
		printf("Condicion a: NO se cumple.\n");
	
	if(negros >= 25)
		printf("Condicion b: Se cumple. Numeros de pixeles negros = %i\n", negros);
	else
    {
		printf("Condicion b: NO se cumple. Numeros de pixeles negros = %i\n", negros);
	}
	if(qr[210 + 2] == 0)
		errores=errores+1;
	
	if (qr[210 + 4] == 0)
		errores=errores+1;
	
	if (qr[210 + 25] == 0)
		errores=errores+1;
	
	if(errores != 0)
	{
		printf("Condicion c: NO se cumple.\n");
		printf("Errores: %i\n", errores);
	}
	else
	{
		printf("Condicion c: Se cumple.\n");
		printf("Errores: %i\n", errores);
	}
	if(errores==0 && v1 && v2 && negros>=25)
		printf("Es original");
	else
		printf("NO es original");

	return 0;
}