/*
Fecha: 01/05/2022
Hora: 7:00 pm.
Version: 1.2
Autor: CRISTIAN DAVID ARANGO TORRES
lenguaje: C(ISO/IEC).
Version lenguaje: 11
Presentado a: Doctor Ricardo Moreno Laverde.
Organizacion: Universidad tecnologica de pereira.
Programa: Ingenieria de sistemas y computacion.
Asignatura: IS284 Programacion 2.
Descripcion: imprime rush juntando todas sus partes.
*/

#include<stdio.h>

/*
Descripcion: imprime x veces un caracter c.
*/
void imprimir_linea(int x, int c)
{
	if(x > 0)
    {
		printf("%c", c);
		imprimir_linea(x - 1, c);
	}
	return;
}

/*
Descripcion: imprime la parte superior de rush.
*/
void parte_superior(int x)
{
	if(x > 0)
    {
		if(x > 1)
        {
			imprimir_linea(x - 1, 42);
		}
		printf("%c", 92);
	}
	return;
}

/*
Descripcion: imprime la parte media de rush.
*/
void parte_media(int x,int y)
{
	if(y > 0)
    {
		printf("*");
		if(x > 1)
        {
			imprimir_linea(x - 2, 32);
			printf("*");
		}
		printf("\n");
		parte_media(x, y - 1);
	}
	return;
}

/*
Descripcion: imprime la parte infeior de rush.
*/
void parte_inferior(int x)
{
	if(x > 0)
    {
		if(x > 1)
        {
			imprimir_linea(x - 1, 42);
		}
		printf("%c", 47);
	}
	return;
}

/*
Descripcion: imprime rush juntando todas sus partes.
*/
void rush(int x, int y)
{
	if(x > 0 && y > 0)
    {
		printf("/");
		parte_superior(x - 1);
		if(y > 1)
        {
			printf("\n");
			parte_media(x,y - 2);
			printf("%c", 92);
			parte_inferior(x - 1);
		}
	}
    return;
}

int main()
{
	int ancho=0,alto=0;
	printf("Ingrese el ancho: ");
	scanf("%i",&ancho);
	printf("\nIngrese el alto: ");
	scanf("%i",&alto);
	rush(ancho,alto);
}