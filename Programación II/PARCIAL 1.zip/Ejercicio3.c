/*
Fecha: 01/05/2022
Hora: 7:00 pm.
Version: 1.2
Autor: CRISTIAN DAVID ARANGO TORRES
lenguaje: C(ISO/IEC).
Version lenguaje: 11
Presentado a: Doctor Ricardo Moreno Laverde.
Organizacion: Universidad tecnologica de pereira.
Programa: Ingenieria de sistemas y computacion.
Asignatura: IS284 Programacion 2.
Descripcion: esta funcion descompene un polinomio en coeficientes y exponentes y los imprime.
*/
#include <stdio.h>

void poli(char[]);
/*
Descripcion: esta funcion descompene un polinomio en coeficientes y exponentes y los imprime.
*/
int main()
{
char polinomio[100];
    printf("ingrese un polinomio:");
    scanf("%s",polinomio);
    printf("Coeficiente     Exponente\n");
    poli(polinomio);

    return 0;
}
void poli(char polinomio[100])
{
    int cont=0,expo=0,coe=0,x=0;
    while(polinomio[cont]!=00)
    {
        if(polinomio[cont] =='X'||polinomio[cont] =='x')
        {
            if (polinomio[cont-1]=='-'||polinomio[cont-1]=='+')
            {
                coe=1;
            }
            if(coe==0)
            {
                coe=1;
            }

                x=1;
        }
        else if(polinomio[cont]=='+')
        {
            
            if(x==1 && expo==0)
                {
                    expo=1;
                    printf("%i\t\t   %i\n",coe,expo);
                    coe=0;expo=0;x=0;
                }
            else if(coe==0);
            else
                printf("%i\t\t   %i\n",coe,expo);
                coe=0;expo=0;x=0;
        }
        else if(polinomio[cont]=='-')
        {
            if(x==1 && expo==0)
            {
                expo=1;
                printf("%i\t\t   %i\n-",coe,expo);
                coe=0;expo=0;x=0;
            }
            else if(polinomio[cont-1]=='(')
            {
            expo=0;
            }
            else if(coe==0)
            {
                printf("-");
            }
            else
            {
                printf("%i\t\t   %i\n-",coe,expo);
                coe=0;expo=0;x=0;
            }
        }
        else if(polinomio[cont]==')')
        {
        printf("%i\t\t   -%i\n",coe,expo);
        coe=0;expo=0;x=0;
        }
        else
        {
            if(x==1)
            {
                expo=(expo*10)+(polinomio[cont]-48);
            }
            else
            {
                coe=(coe*10)+(polinomio[cont]-48);
            }
        }
    if(polinomio[cont+1]==00)
    {
        if(expo==0 && x==1)
        {
            expo=1;
        }
        if(polinomio[cont]!=')')
        printf("%i\t\t   %i",coe,expo);
    }
    cont = cont + 1;
    }
}