#include<stdio.h>
#include<string.h>

/*
Fecha: 01/05/2022
Hora: 7:00 pm.
Version: 1.2
Autor: CRISTIAN DAVID ARANGO TORRES
lenguaje: C(ISO/IEC).
Version lenguaje: 11
Presentado a: Doctor Ricardo Moreno Laverde.
Organizacion: Universidad tecnologica de pereira.
Programa: Ingenieria de sistemas y computacion.
Asignatura: IS284 Programacion 2.
*/

int pluralMayus(char [], char[]);
int plural(char [],char[]);

//Plural en mayuscula
int pluralMayus(char palabra[50],char final[50])
{
    int ultpos=0;

    ultpos=palabra[(strlen(palabra) - 1)];

	if(ultpos==89)
	{
	palabra[strlen(palabra) - 1] = 73;
	palabra[strlen(palabra)] = 69;
	palabra[strlen(palabra)] = 83;
	palabra[strlen(palabra)]=0;
	}
	else if(ultpos >= 65 && ultpos <= 90)
	{
	palabra[strlen(palabra)]='S';
	palabra[strlen(palabra)]=0;
	}
    strcpy(final,palabra);
	return 0;
}


//Plural en minuscula
int plural(char palabra[50],char final[50])
{
    int ultpos=0;

    ultpos=palabra[(strlen(palabra) - 1)];

	if(ultpos == 121)
    {
		palabra[strlen(palabra) - 1] =105;
		palabra[strlen(palabra)] =101;
		palabra[strlen(palabra)] =115;
		palabra[strlen(palabra)]=0;
	}
    else if(ultpos >= 97 && ultpos <=122)
    {
		palabra[strlen(palabra)]=115;
		palabra[strlen(palabra)]=0;
	}
    strcpy(final,palabra);
    
	return 0;
}

//MAIN
int main(){
	char palabra[50];
    char final[50];
	int ultcaracter = 0;
	
    printf("Ingrese palabra: ");
    scanf("%s",&palabra);
	ultcaracter = palabra[(strlen(palabra) - 1)];
	if(ultcaracter=='y')
        plural(palabra,final);
    else if(ultcaracter >= 97 && ultcaracter <= 122)
        plural(palabra,final);
    else if(ultcaracter=='Y')
        pluralMayus(palabra,final);
    else if(ultcaracter >= 65 && ultcaracter <= 90)
        pluralMayus(palabra,final);
	printf("%s",final);
		
}